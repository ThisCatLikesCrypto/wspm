# List of commands in editor
exit close the file
run run the file (ESDLang only)
rewrite (linenumber) Rewrites the given line
insert creates a new line before a given line number
delete (linenumber) deletes the line at a given line number